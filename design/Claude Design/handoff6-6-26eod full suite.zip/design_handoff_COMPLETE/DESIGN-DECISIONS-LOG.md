# DESIGN DECISIONS LOG — Ananda Taskboard
> Per **RULE #1** (see `CLAUDE.md`): every decision from a Claude Design session is recorded
> here so it can be applied **retroactively** to older modules. This is the single source of
> truth for cross-cutting changes. When starting work, read this and bring stale surfaces up
> to date. Format per entry: **what changed (before → after) · exact spec · affected surfaces**.
>
> Affected-surface keys: **APP** = `Ananda Taskboard.html` (canonical web) · **MOB** =
> `mobile/` · **MT** = `multitenancy/` · **AUTH** = `auth/` · **HELP** = `help-onboarding/`.

---

## GLOBAL conventions (apply to EVERY module)

### D1 · Status rename “Ready for Review” → “Review”
- Before: 5th status labeled “Ready for Review”. After: **“Review”**, color unchanged
  **purple `#7a5aa6`**, still 2nd-to-last (To Do · In Progress · Delayed · **Review** · Done).
- Spec: rename the label everywhere it appears — Kanban column, status pill, summary strip,
  status filter, any sample data, and all 13 locale strings. Color/order/behavior unchanged.
- Surfaces: **APP ✅ (done)** · **MOB ✅ (already “Review”)** · **MT / AUTH** check any status
  references · **HELP ✅**. Older handoff `design_handoff_ananda_taskboard/README.md` still
  says “Ready for Review” — **stale, update if reused**.

### D2 · No native dropdowns — custom control everywhere
- After: every `<select>`-like control is the **custom trigger + popover** (surface bg, tan
  border `#e4d8bb`, radius 8px, caret SVG inset ~11px; popover lists options w/ a check on
  the selected). Applies to Project, Sub-project, Status “Change to…”, Priority, the
  “+ Add person or group…” assignee picker, and all filter/sort triggers.
- Surfaces: **HELP ✅**. **APP / MOB / MT / AUTH** — audit for any remaining native selects
  and convert. (Hard UI rule already forbids native select carets; this extends it to a full
  custom popover.)

### D3 · Fonts — Instrument Sans for ALL titles; Fraunces wordmark-only
- After: dialog/calendar/section/screen titles use **Instrument Sans** (weight 700).
  **Fraunces** is used **only** for the “Ananda Taskboard” wordmark + its italic tagline.
- Surfaces: all. Audit any `--f-display`/Fraunces on headings and switch to `--f-ui`.

### D4 · Links field — textarea → structured list
- Before: `<textarea>` “Links (one URL per line)”. After: a **list of link rows** (chain
  icon · URL field · ✕ remove) + a **+ Add link** button.
- Surfaces: **HELP ✅ (Task Popup + Subtask editor)**. **APP** Task Popup `#mLinks` textarea
  (`Ananda Taskboard.html` ~line 2191) is **stale — migrate**. **MOB** task detail Links —
  migrate. Keep both in sync.

### D5 · Buttons — clear hierarchy
- After: primary = filled navy `#1e3a6e` + cream text `#fbf6ea` + **permanent** elevation
  shadow; secondary = surface + tan border; danger = surface + **red** border/text `#b4452f`;
  in dialog footers **Delete is on the LEFT in red**, Save (primary) on the right. All read as
  outlined buttons (not text links). (The `!important` overrides in the HELP prototype are an
  artifact of a base `button` reset — not needed with proper component styling.)
- Surfaces: all dialog footers.

---

## CALENDAR

### D6 · “No date” → “Unscheduled Tasks”
- Before: calendar-header button “📋 No date (N)” + modal “No date — {N} tasks”. After:
  **“Unscheduled Tasks (N)”** button (line-art **calendar-with-X** icon, icon centered to
  label), **emphasized** (blue outline + tinted fill + navy count pill), **hidden at N=0**,
  wraps full-width on narrow widths. Modal/sheet titled **“Unscheduled tasks (N)”**.
- Locale keys `cal.noDate` / `cal.noDateTitle` → update copy to “Unscheduled …”.
- Surfaces: **HELP ✅**. **APP / MOB** Monthly+Weekly headers — apply.

### D7 · Unscheduled list = standard List methodology (no deadline/recurrence)
- Web: a **sortable column table** — Task · Project · Sub-project · Assignees · Status — with
  a filter bar **Assignee · Project · Status** (NO Deadline/Recurrence; those don’t apply to
  undated tasks). Mobile: the compact **`.crow`** list (Trash/Approvals aesthetic) in a bottom
  sheet over the live calendar, same filters + an A–Z sort, **no date/time**.
- Surfaces: **HELP ✅**. **APP / MOB** — apply.

### D8 · Weekly task-bar corner radius: pill → 5px
- Before: `.wk-bar{border-radius:var(--r-pill)}`. After: **`5px`** (softer, not a full pill).
- Surfaces: **APP ✅ (done, `Ananda Taskboard.html`)** · **HELP ✅** · **MOB** Weekly is
  agenda-style (no `.wk-bar`) → N/A.

### D9 · Done hidden from calendars
- Done tasks no longer appear on Monthly/Weekly, the Unscheduled list, or Copy Summary.
- Surfaces: APP/MOB calendar + summary logic.

### D10 · Mobile Monthly — holiday/event names are icon-only in cells
- Cells show **only** the star (holiday) / megaphone (event) **icon** (centered); the names
  appear in the **day’s task list when the day is tapped** (Monthly only). Web Monthly keeps
  inline names (cells are wide enough).
- Surfaces: **HELP ✅ (mobile)** · **MOB** — apply.

---

## TASK / SUBTASKS

### D11 · Subtasks are mini-tasks (NEW feature)
- In the Task Popup, a **Subtasks** section: header w/ status-count dots + a `done/total`
  progress bar (To-Do share is **empty track**). Rows are single-line: priority · title ·
  **aligned avatar column** (◇ for groups) · **status as the custom pill+popover** · ✕ delete
  · a title-only quick-add. Clicking a row **swaps the modal body** to a detail panel (never a
  stacked modal).
- Surfaces: **HELP ✅**. **APP** Task Popup already has a Subtasks section — reconcile to this
  exact row/控件 design. **MOB** task detail — apply.

### D12 · Subtask detail panel
- Header is a **breadcrumb** (no title): `← Back · {Parent} #142 › {Sub-task} #142.2` + a
  **Share** button + ✕. Subtask IDs are **parent.index** (`#142.2`). Field label is
  **“Sub-task name”**. Fields & controls mirror the Task Popup **exactly** (Status pill +
  “Change to…”, Priority custom popover, Assignees chip+add, Details|Requirements, dates,
  times, **Links list**). Footer: **Delete (left, red) · Save**. No “Back to subtasks” footer
  button (breadcrumb Back covers it). Mobile: breadcrumb stacks (Back/✕/Share on top row,
  Task › Sub-task below); two-up rows stack to one column.
- Behavior: subtasks capped one level deep (no sub-subtasks). Anyone assigned to a subtask
  (or in a group assigned) can edit it.

### D13 · Time requires a date (validation)
- A start/end time cannot be set without a **date** (start date or deadline). Times are
  **both-or-neither** (“Set both a start and end time, or neither.” blocks Save). Therefore
  **Unscheduled tasks never have a time** (no “Time” sort, no “All day” label).
- Surfaces: APP/MOB Task Popup + subtask editor validation.

### D14 · Unscheduled web-table assignees = avatar-only + name on hover
- In the Unscheduled table’s Assignees column, show the **overlapping mini-avatars only**,
  full name on hover (`title`) — not avatar+name chips.

---

## HELP / ONBOARDING (NEW feature module)

### D15 · Help lives in the account menu (not the top bar)
- **“Help & FAQ”** sits at the **top of the account menu** (Admin Ada ▾), above Settings/etc.;
  available to **everyone**. **Trash** also moved into the account menu. Top bar = Approvals ·
  Team · Projects (lean). A purple **What’s-New dot** (`--new #6d4aff`) rides the user pill +
  Help row when unseen features exist. Mobile: Help in the ⋯ overflow.

### D16 · Welcome card (once-ever)
- First-login modal: 3 line-art bullets (open a **Project** tab · switch views · **+ New
  task**), helper line pointing to **account-menu Help**, single **Got it** button (no Skip).

### D17 · Help center — scannable, not a wall of text
- Search + What’s-New block + **collapsible counted sections** (collapsed by default).
  Articles expand inline. **Search results expand inline** to the article body.
- **Admin articles carry NO chip** — they live under “For admins” and each body states
  “admins only”; typing **“admin”** in search surfaces every admin ticket. (Old grey “Admin”
  chip removed.)

### D18 · Line-art icons, never emoji
- Every affordance uses stroked SVG line-art; the original hand-off’s 📋/✨/🙏/🗂️ placeholders
  are all replaced. Applies to any new surface.

---

## Process / packaging
### D19 · Decisions log + retroactive propagation (this entry)
- New **RULE #1**: log every decision here and retro-apply to older modules. The complete
  cross-module handoff lives in `design_handoff_COMPLETE/` with `MASTER-HANDOFF.md`.

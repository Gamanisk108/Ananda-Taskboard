# Project notes — Ananda Taskboard

## RULE #0 — Fidelity first (process; non-negotiable)
**When building any mockup/variation on top of designs that already exist for this product, FIRST recreate the previously-agreed-upon design with 100% fidelity — exact markup, classes, structure, fields, spacing, fonts and behavior — by reading the real source file (`Ananda Taskboard.html`) and copying it. Only after the existing design is reproduced faithfully do you add the new feature on top.** Never ship a simplified, approximate, or "lighter" version of an existing surface (top bar, List view, Task Popup, calendar, dialogs, rows, filters). If unsure how something currently looks, open the source and match it — do not guess. Approximations have repeatedly wasted the user's time and are unacceptable. (Carry this practice into every project: existing agreed designs are reproduced exactly before anything new is layered on.)

## RULE #1 — Log every design decision (process; non-negotiable)
**Every decision made in a Claude Design session — a change, rename, restyle, behavior rule, or new convention — MUST be recorded in `DESIGN-DECISIONS-LOG.md` at the project root.** Log it the moment it's agreed, with: date, what changed (before → after), the exact spec (values/markup), and **every surface/file it affects** (so it can be applied retroactively to older modules — canonical app, mobile, multi-tenancy, auth, and any handoff). The log is the single source of truth for cross-cutting changes; when starting any work, read it and bring stale surfaces up to date. A decision that lives only in chat is considered lost — if it's not in the log, it didn't happen.

## Brand
- "Temple of Light" / Ananda Connect aesthetic. Fonts: Instrument Sans (all UI **and all titles/headings** — dialog titles, calendar titles, section headers, screen titles), Red Hat Mono (numbers — plain zero, no dot/slash). **Fraunces is used ONLY for the brand wordmark "Ananda Taskboard" and its italic tagline — never for dialog/section/calendar titles** (the app's `h1,h2,h3` are `--f-ui`, weight 700). The user has rejected Fraunces titles repeatedly.
- Logo: navy lotus mark at `assets/ananda-mark.png`.
- **Status pipeline is FIVE statuses, order matters:** To Do (gray) · In Progress (BLUE) · Delayed (RED) · **Review** (PURPLE `#7a5aa6`, renamed from "Ready for Review") · Done (green). Review sits 2nd-to-last, right before Done. Always include all five anywhere status appears.

## Canonical app chrome (the source of truth is `Ananda Taskboard.html` — match it, don't simplify)
- **The faux board behind any dialog/overlay MUST be the real List view, never a stripped-down placeholder.** List rows are a dense table with these columns: **Task** (with a leading priority icon) · **Project** (proj-pill, tinted by project color) · **Sub-project** (proj-pill) · **Assignees** (avatar+name chips, ◇ for groups) · **Status** (pill + caret) · **Deadline** (mono; red if overdue, amber if due-soon) · **Recurs**. Overdue rows tint red, due-soon amber, with a red-! / amber-clock badge by the name.
- **Always include the filter bar** above the list: a search box, then Assignee / Status / Priority (checkbox multi-selects, count pill) and Deadline / Recurrence (single-selects), plus a Clear that shows only when a filter is active. And the **summary strip**: total · Overdue (red) · Due soon (amber) · a count per status (all 5).
- Projects & sub-projects render as **proj-pills everywhere** they're listed (lists, cards, tables) — never a bare color swatch.
- Reuse the real `Ananda Taskboard.html` component markup/classes when building new surfaces; if reproducing in a module, copy the real structure rather than re-inventing a lighter version.
- Single self-contained HTML file. Light + dark themes (theme toggle lives next to the logo).

## Hard UI rules (apply to ALL future work here)
- **Never leave a native `<select>` caret.** Always strip `appearance:none` and draw a custom chevron inset ~11px from the right edge (see the global `select` rule). Native carets sit too close to the edge — the user has rejected this repeatedly. Also: set input/select backgrounds with `background-color:` NOT the `background:` shorthand, or the shorthand wipes the caret image and it tiles. And NEVER let a later rule set `padding:` shorthand on selects (it resets padding-right to ~10px and the caret overlaps the text) — the custom-caret rule keeps `padding-right:30px !important` for this reason.
- Color swatch pickers must be **circles**, and offer a small recommended palette in addition to a custom picker (see `openColorPicker`).
- Section-header labels use the UI sans font (uppercase), NOT the Fraunces serif.
- Destructive actions (restore board, delete forever) need a confirmation popup explaining what will happen (`openConfirm`).
- Header must stay on one line at small widths (collapse button labels to icons; never wrap).
